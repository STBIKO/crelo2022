<?php $__env->startSection('title', translate('messages.deliveryman_registration')); ?>
<?php $__env->startPush('css_or_js'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.13/css/intlTelInput.css"/>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="m-0">
        <div class="container">
            <!-- Page Header -->
            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col-sm mb-2 mb-sm-0">
                        <h1 class="page-header-title text-center"><i class="tio-add-circle-outlined"></i>
                            <?php echo e(translate('messages.deliveryman_application')); ?></h1>
                    </div>
                </div>
            </div>
            <!-- End Page Header -->
            <div class="row">
                <div class="card shadow-sm col-12">
                    <form class="card-body" action="<?php echo e(route('deliveryman.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <small class="nav-subtitle"><?php echo e(translate('messages.deliveryman')); ?>

                            <?php echo e(translate('messages.info')); ?></small>
                        <br>
                        <div class="row mt-3">
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <div class="form-group">
                                    <label class="input-label"
                                        for="exampleFormControlInput1"><?php echo e(translate('messages.first')); ?>

                                        <?php echo e(translate('messages.name')); ?></label>
                                    <input type="text" name="f_name" class="form-control"
                                        placeholder="<?php echo e(translate('messages.first')); ?> <?php echo e(translate('messages.name')); ?>" required
                                        value="<?php echo e(old('f_name')); ?>">
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-6 col-sm-12">
                                <div class="form-group">
                                    <label class="input-label"
                                        for="exampleFormControlInput1"><?php echo e(translate('messages.last')); ?>

                                        <?php echo e(translate('messages.name')); ?></label>
                                    <input type="text" name="l_name" class="form-control"
                                        placeholder="<?php echo e(translate('messages.last')); ?> <?php echo e(translate('messages.name')); ?>"
                                        value="<?php echo e(old('l_name')); ?>" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-4 col-12">
                                <div class="form-group">
                                    <label class="input-label"
                                        for="exampleFormControlInput1"><?php echo e(translate('messages.email')); ?></label>
                                    <input type="email" name="email" class="form-control"
                                        placeholder="Ex : ex@example.com" value="<?php echo e(old('email')); ?>" required>
                                </div>
                            </div>
                            <div class="col-sm-4 col-12">
                                <div class="form-group">
                                    <label class="input-label"
                                        for="exampleFormControlInput1"><?php echo e(translate('messages.deliveryman')); ?>

                                        <?php echo e(translate('messages.type')); ?></label>
                                    <select name="earning" class="form-control">
                                        <option value="1"><?php echo e(translate('messages.freelancer')); ?></option>
                                        <option value="0"><?php echo e(translate('messages.salary_based')); ?></option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-4 col-12">
                                <div class="form-group">
                                    <label class="input-label"
                                        for="exampleFormControlInput1"><?php echo e(translate('messages.zone')); ?></label>
                                    <select name="zone_id" class="form-control" required
                                        data-placeholder="<?php echo e(translate('messages.select')); ?> <?php echo e(translate('messages.zone')); ?>">
                                        <option value="" readonly="true" hidden="true"><?php echo e(translate('messages.select')); ?>

                                            <?php echo e(translate('messages.zone')); ?></option>
                                        <?php $__currentLoopData = \App\Models\Zone::active()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(isset(auth('admin')->user()->zone_id)): ?>
                                                <?php if(auth('admin')->user()->zone_id == $zone->id): ?>
                                                    <option value="<?php echo e($zone->id); ?>" selected><?php echo e($zone->name); ?>

                                                    </option>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <option value="<?php echo e($zone->id); ?>"><?php echo e($zone->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 col-12">
                                <div class="form-group">
                                    <label class="input-label"
                                        for="exampleFormControlInput1"><?php echo e(translate('messages.identity')); ?>

                                        <?php echo e(translate('messages.type')); ?></label>
                                    <select name="identity_type" class="form-control">
                                        <option value="passport"><?php echo e(translate('messages.passport')); ?></option>
                                        <option value="driving_license"><?php echo e(translate('messages.driving')); ?>

                                            <?php echo e(translate('messages.license')); ?></option>
                                        <option value="nid"><?php echo e(translate('messages.nid')); ?></option>
                                        <option value="restaurant_id"><?php echo e(translate('messages.store')); ?>

                                            <?php echo e(translate('messages.id')); ?></option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6 col-12">
                                <div class="form-group">
                                    <label class="input-label"
                                        for="exampleFormControlInput1"><?php echo e(translate('messages.identity')); ?>

                                        <?php echo e(translate('messages.number')); ?></label>
                                    <input type="text" name="identity_number" class="form-control"
                                        value="<?php echo e(old('identity_number')); ?>" placeholder="Ex : DH-23434-LS" required>
                                </div>
                            </div>
                            <div class="col-md-12 col-12">
                                <div class="form-group">
                                    <label class="input-label"
                                        for="exampleFormControlInput1"><?php echo e(translate('messages.identity')); ?>

                                        <?php echo e(translate('messages.image')); ?></label>
                                    <div>
                                        <div class="row" id="coba"></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <small class="nav-subtitle text-capitalize"><?php echo e(translate('messages.login')); ?>

                            <?php echo e(translate('messages.info')); ?></small>
                        <br>
                        <div class="row mt-3">
                            <div class="col-md-6 col-12">
                                <div class="form-group">
                                    <label class="input-label" for="phone"><?php echo e(translate('messages.phone')); ?></label>
                                    <div class="input-group">
                                        <input type="tel" name="tel" id="phone" placeholder="Ex : 017********"
                                            class="form-control" value="<?php echo e(old('tel')); ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-12">
                                <div class="form-group">
                                    <label class="input-label"
                                        for="exampleFormControlInput1"><?php echo e(translate('messages.password')); ?></label>
                                    <input type="text" name="password" class="form-control" placeholder="Ex : password"
                                        value="<?php echo e(old('password')); ?>" required>
                                </div>
                            </div>
                        </div>
                        <div class="row d-flex justify-content-center">
                            <div class="col-md-8 col-12">
                                <div class="form-group">
                                    <center class="pt-4">
                                        <img style="height: 200px;border: 1px solid; border-radius: 10px;" id="viewer"
                                            src="<?php echo e(asset('public/assets/admin/img/400x400/img2.jpg')); ?>"
                                            alt="delivery-man image" />
                                    </center>
                                    <label  class="input-label"><?php echo e(translate('messages.deliveryman')); ?> <?php echo e(translate('messages.image')); ?><small
                                        style="color: red">* ( <?php echo e(translate('messages.ratio')); ?> 1:1 )</small></label>
                                    <div class="custom-file">
                                        <input type="file" name="image" id="customFileEg1" class="form-control"
                                            accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button type="submit"
                            class="btn btn-primary float-right"><?php echo e(translate('messages.submit')); ?></button>
                    </form>
                </div>
            </div>
        </div>

    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script src="<?php echo e(asset('public/assets/admin')); ?>/js/toastr.js"></script>
    <?php echo Toastr::message(); ?>


    <?php if($errors->any()): ?>
        <script>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.error('<?php echo e($error); ?>', Error, {
                CloseButton: true,
                ProgressBar: true
                });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </script>
    <?php endif; ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.13/js/intlTelInput.min.js"
        integrity="sha512-QMUqEPmhXq1f3DnAVdXvu40C8nbTgxvBGvNruP6RFacy3zWKbNTmx7rdQVVM2gkd2auCWhlPYtcW2tHwzso4SA=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.13/js/intlTelInput-jquery.min.js"
        integrity="sha512-hkmipUFWbNGcKnR0nayU95TV/6YhJ7J9YUAkx4WLoIgrVr7w1NYz28YkdNFMtPyPeX1FrQzbfs3gl+y94uZpSw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.13/js/utils.min.js"
             integrity="sha512-lv6g7RcY/5b9GMtFgw1qpTrznYu1U4Fm2z5PfDTG1puaaA+6F+aunX+GlMotukUFkxhDrvli/AgjAu128n2sXw=="
             crossorigin="anonymous" referrerpolicy="no-referrer"></script> -->
    <link rel="shortcut icon" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.13/img/flags.png"
        type="image/x-icon">
    <link rel="shortcut icon" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.13/img/flags@2x.png"
        type="image/x-icon">
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function(e) {
                    $('#viewer').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#customFileEg1").change(function() {
            readURL(this);
        });
        <?php ($country = \App\Models\BusinessSetting::where('key', 'country')->first()); ?>
        var phone = $("#phone").intlTelInput({
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/8.4.6/js/utils.js",
            autoHideDialCode: true,
            autoPlaceholder: "ON",
            dropdownContainer: document.body,
            formatOnDisplay: true,
            hiddenInput: "phone",
            initialCountry: "<?php echo e($country ? $country->value : auto); ?>",
            placeholderNumberType: "MOBILE",
            separateDialCode: true
        });
        // $("#phone").on('change', function(){
        //     $(this).val(phone.getNumber());
        // })
    </script>
    <script src="<?php echo e(asset('public/assets/admin/js/spartan-multi-image-picker.js')); ?>"></script>
    <script type="text/javascript">
        $(function() {
            $("#coba").spartanMultiImagePicker({
                fieldName: 'identity_image[]',
                maxCount: 5,
                rowHeight: '120px',
                groupClassName: 'col-lg-2 col-md-4 col-sm-4 col-6',
                maxFileSize: '',
                placeholderImage: {
                    image: '<?php echo e(asset('public/assets/admin/img/400x400/img2.jpg')); ?>',
                    width: '100%'
                },
                dropFileLabel: "Drop Here",
                onAddRow: function(index, file) {

                },
                onRenderedPreview: function(index) {

                },
                onRemoveRow: function(index) {

                },
                onExtensionErr: function(index, file) {
                    toastr.error('<?php echo e(translate('messages.please_only_input_png_or_jpg_type_file')); ?>', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                },
                onSizeErr: function(index, file) {
                    toastr.error('<?php echo e(translate('messages.file_size_too_big')); ?>', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.landing.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/crelocok/public_html/resources/views/dm-registration.blade.php ENDPATH**/ ?>